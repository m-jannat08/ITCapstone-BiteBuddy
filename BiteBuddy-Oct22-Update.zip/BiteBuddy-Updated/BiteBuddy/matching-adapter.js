/* Convert the existing BiteBuddy preference form into the
   input expected by matchingAlgorithm.js. */

(function () {
    'use strict';

    const choices = (data, category) =>
        data?.[category]?.choices || [];

    function adapt(data) {
        const cuisines = choices(data, 'Cuisine');
        const budgets = choices(data, 'Budget');
        const distancesSelected = choices(data, 'Distance');

        const anySelected = values =>
            values.some(
                value => String(value).trim().toLowerCase() === 'any'
            );

        const anyBudget = anySelected(budgets);
        const anyDistance = anySelected(distancesSelected);

        // Budget price tiers:
        // 1 = Under $15
        // 2 = $15–$25
        // 3 = $25–$40
        // 4 = $40+
        const tiers = budgets
            .map(choice =>
                choice.includes('Under') ? 1 :
                choice.includes('15') && choice.includes('25') ? 2 :
                choice.includes('25') && choice.includes('40') ? 3 :
                choice.includes('40') ? 4 :
                null
            )
            .filter(Boolean);

        // Extract the distance number from options such as
        // "Within 5 miles".
        const distances = distancesSelected
            .map(choice =>
                Number((choice.match(/\d+/) || [])[0])
            )
            .filter(n => Number.isFinite(n) && n > 0);

        const diet = choices(data, 'Dietary Needs');

        const supported = [
            'Vegetarian',
            'Vegan',
            'Gluten-Free',
            'Halal'
        ];

        const unknown = diet.filter(
            restriction => !supported.includes(restriction)
        );

        if (unknown.length || data?.extraDietaryDetails) {
            throw new Error(
                'Allergy and custom dietary requirements cannot be ' +
                'verified by the current restaurant catalog. Please ' +
                'verify directly with restaurants before recommending one.'
            );
        }

        return {
            cuisines: cuisines.length ? cuisines : ['Any'],

            // Any disables budget scoring.
            budget: anyBudget
                ? 'Any'
                : (tiers.length ? Math.min(...tiers) : 'Any'),

            // Any disables distance scoring.
            distance: anyDistance
                ? 'Any'
                : (distances.length ? Math.min(...distances) : 'Any'),

            dietaryRestrictions: diet.filter(
                restriction => supported.includes(restriction)
            )
        };
    }

    // Convert restaurant catalog entries to the algorithm's format.
    function toCatalog(list) {
        return list.map(restaurant => ({
            id: restaurant.id,
            name: restaurant.name,
            cuisine: (restaurant.cuisines || [])[0] || '',
            price: restaurant.price.level,
            distanceMiles: restaurant.distanceMiles,

            dietaryOptions: Object.entries({
                vegetarian: 'Vegetarian',
                vegan: 'Vegan',
                glutenFree: 'Gluten-Free',
                halal: 'Halal'
            })
                .filter(([key]) =>
                    restaurant.dietary?.[key] === 'yes'
                )
                .map(([, value]) => value)
        }));
    }

    window.BiteBuddyMatchingAdapter = {
        adapt,
        toCatalog
    };
})();
