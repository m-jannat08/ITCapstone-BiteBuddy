const restaurants = window.BiteBuddyMatchingRestaurants || [];

// 1. Score cuisine preference.
function scoreCuisine(restaurant, preferences) {
    const cuisines = preferences.cuisines || [];

    // Any or no selection means all cuisines match.
    if (
        !cuisines.length ||
        cuisines.some(value => String(value).trim().toLowerCase() === "any")
    ) {
        return 100;
    }

    return cuisines.includes(restaurant.cuisine) ? 100 : 0;
}

// 2. Score budget preference.
function scoreBudget(restaurant, preferences) {
    const rawBudget = preferences.budget;

    // Any or no selection means budget does not affect the score.
    if (
        rawBudget == null ||
        String(rawBudget).trim().toLowerCase() === "any" ||
        rawBudget === ""
    ) {
        return 100;
    }

    const budget = Number(rawBudget);

    if (!Number.isFinite(budget) || budget < 1) {
        return 100;
    }

    const difference = restaurant.price - budget;

    if (difference <= 0) return 100;
    if (difference === 1) return 60;

    return 20;
}

// 3. Score distance preference.
function scoreDistance(restaurant, preferences) {
    const rawDistance = preferences.distance;

    // Any or no selection means distance does not affect the score.
    if (
        rawDistance == null ||
        String(rawDistance).trim().toLowerCase() === "any" ||
        rawDistance === ""
    ) {
        return 100;
    }

    const maxDistance = Number(rawDistance);

    if (!Number.isFinite(maxDistance) || maxDistance <= 0) {
        return 100;
    }

    if (restaurant.distanceMiles > maxDistance) {
        return 0;
    }

    // Restaurants closer than the limit score higher.
    return Math.round(
        20 + (1 - restaurant.distanceMiles / maxDistance) * 80
    );
}

// 4. Calculate one person's weighted score.
function scoreRestaurantForPerson(restaurant, preferences) {
    const cuisine = scoreCuisine(restaurant, preferences);
    const budget = scoreBudget(restaurant, preferences);
    const distance = scoreDistance(restaurant, preferences);

    const total =
        cuisine * 0.50 +
        budget * 0.35 +
        distance * 0.15;

    return {
        cuisine,
        budget,
        distance,
        total: Math.round(total * 10) / 10
    };
}

// 5. Dietary restrictions are the only hard filters.
function isRestaurantEligible(restaurant, allPreferences) {
    for (const preferences of allPreferences) {
        const restrictions = preferences.dietaryRestrictions || [];

        for (const restriction of restrictions) {
            if (!restaurant.dietaryOptions.includes(restriction)) {
                return false;
            }
        }
    }

    return true;
}

// 6. Rank restaurants for the whole group.
function findRestaurantMatches(allPreferences) {
    if (!Array.isArray(allPreferences) || allPreferences.length === 0) {
        return [];
    }

    const eligibleRestaurants = restaurants.filter(restaurant =>
        isRestaurantEligible(restaurant, allPreferences)
    );

    const rankedRestaurants = eligibleRestaurants.map(restaurant => {
        const individualScores = allPreferences.map(preferences =>
            scoreRestaurantForPerson(restaurant, preferences)
        );

        const averageScore =
            individualScores.reduce(
                (sum, score) => sum + score.total,
                0
            ) / individualScores.length;

        const lowestScore = Math.min(
            ...individualScores.map(score => score.total)
        );

        // Group fairness: 60% average + 40% lowest individual score.
        const groupScore =
            0.60 * averageScore + 0.40 * lowestScore;

        return {
            id: restaurant.id,
            name: restaurant.name,
            cuisine: restaurant.cuisine,
            price: restaurant.price,
            distanceMiles: restaurant.distanceMiles,
            dietaryOptions: restaurant.dietaryOptions,
            individualScores,
            averageScore: Math.round(averageScore * 10) / 10,
            lowestScore: Math.round(lowestScore * 10) / 10,
            groupScore: Math.round(groupScore * 10) / 10
        };
    });

    rankedRestaurants.sort((a, b) => b.groupScore - a.groupScore);

    // Return the top three recommendations.
    return rankedRestaurants.slice(0, 3);
}

window.BiteBuddyMatching = {
    restaurants,
    scoreCuisine,
    scoreBudget,
    scoreDistance,
    scoreRestaurantForPerson,
    isRestaurantEligible,
    findRestaurantMatches
};